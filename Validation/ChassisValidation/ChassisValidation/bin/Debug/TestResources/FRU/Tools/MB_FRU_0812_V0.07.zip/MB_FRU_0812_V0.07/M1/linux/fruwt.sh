#!/bin/sh

FW_FILE=../../fru/mb.txt
INI_FILE=../fru_m1.ini

if test -f $FW_FILE
then
	./fwtool fru write 0 $FW_FILE $INI_FILE
else
	echo "$FW_FILE not exist!"
fi
