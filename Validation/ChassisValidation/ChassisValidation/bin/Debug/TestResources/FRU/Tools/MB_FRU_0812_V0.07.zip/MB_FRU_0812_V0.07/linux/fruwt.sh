#!/bin/sh
./fwtool fru write 0 ../FRU/MB.txt ../FRU/FRU.ini
